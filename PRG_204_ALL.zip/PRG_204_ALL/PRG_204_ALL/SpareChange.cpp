
#include <cstdio>
#include <string.h>

//#include is referencing an existing code

void SpareChange( void )
	//function
{
	double amount = 4.36;
	printf( "In my pocket, I have %f dollars.", amount );
	return;
}
