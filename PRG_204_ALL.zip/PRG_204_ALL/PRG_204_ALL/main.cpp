#define string char*

void SpareChange( void );
void Lunch( void );
void Net_weekly_pay( void );
void Floor( void );
void Furniture (void) ;
void Guess (void);

int main( int argc, string argv[  ] )
{
	//Floor( );
	//SpareChange(  );
	//Lunch( );
	//Net_weekly_pay(  );
	//Furniture ( ) ;
	Guess ();
	return 0;
}
